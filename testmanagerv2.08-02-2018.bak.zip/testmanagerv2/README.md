# testmanagerv2

V2: improved logic by creating classes (the right way, this time);



ToDo:
 - manage the headers somehow, include dependencies (done);
 - make a navbar, multiple choices available
 - make a table with initial selections or a menu with redirecting to docs, etc.;
 - include and fix that MacOS first page, maybe
 - projects (subsection is testcase or section / subsection);
 - implement errors and notifications; errors done through sweetalert, notifications, to be determined;
 - implement user messages through session variables or something else (done) maybe stored in the db and once read (to be created), set a flag to read or something (also, to be created);
 - implement alerts, like meeting alerts, with JS maybe, if PHP not possible (or even AJAX);
 - search function with AJAX (very important);
