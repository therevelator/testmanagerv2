<?php

/**
 *
 */
class headers
{

  function __construct()
  {
    echo '<head>
      <meta charset=utf-8>
      <title></title>
      <link type="text/css" rel="stylesheet" href="css/login.css" />
      <link type="text/css" rel="stylesheet" href="http://cdn.dcodes.net/2/menus/imenu/css/dc_imenu.css" />
      <link href=\'https://fonts.googleapis.com/css?family=Oswald\' rel=\'stylesheet\' type=\'text/css\'>
      <link href=\'https://fonts.googleapis.com/css?family=Open+Sans\' rel=\'stylesheet\' type=\'text/css\'>
      <link type="text/css" rel="stylesheet" href="css/sweetalert.css" />
      <script src="js/sweetalert.min.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    </head>';
  }
}












?>
