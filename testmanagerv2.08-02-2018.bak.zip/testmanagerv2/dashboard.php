<?php
//manage the headers somehow, include dependencies
//make a navbar, multiple choices available
//make a table with initial selections or a menu with redirecting to docs,
//include and fix that MacOS first page, maybe
//projects (subsection is testcase or section / subsection)
//implement errors and notifications
//implement user messages through session variables or something else maybe stored in the db and once read, set a flag to read or something
//implement alerts, like meeting alerts, with JS maybe, if PHP not possible (or even AJAX);
//search function with AJAX (very important)
?>
